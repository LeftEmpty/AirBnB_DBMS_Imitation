# Overview

## Phases 1 - 3
Each folder named "Schmaeling-Tom_32111919_ DLBDSPBDM01-.." contains both the file used for submission and a folder containing all files used to create said submission.
- Each of these folder has a readme.md that explains the content.

## Final Product
The folder without extension, simply called "Schmaeling-Tom_32111919_DLBDSPBDM01" represents the **final product**.
- this folder contains the abstract, the manual & documentation, and a folder with all (well documented) SQL files.