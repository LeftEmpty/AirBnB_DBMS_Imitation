draw.io files used in the creation of th ER files

the later one being used as a comparison in the phase 2 presentation